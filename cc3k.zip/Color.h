#ifndef COLOR
#define COLOR

enum class Color
{
    Red,
    Yellow,
    Blue,
    Green,
    Cyan,
    Magenta,
    None
};

#endif
