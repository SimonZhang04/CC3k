#include "StatViewer.h"

float StatViewer::getStat() const
{
   return base();
}
