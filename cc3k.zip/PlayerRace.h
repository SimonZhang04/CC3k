#ifndef PLAYERRACE_H
#define PLAYERRACE_H
#include <string>

enum class PlayerRace
{
   Human,
   Dwarf,
   Elf,
   Orc
};

#endif
