#ifndef POTIONTYPE_H
#define POTIONTYPE_H

enum class PotionType
{
   RestoreHealth,
   BoostAtk,
   BoostDef,
   PoisonHealth,
   WoundAtk,
   WoundDef
};

#endif
