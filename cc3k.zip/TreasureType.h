#ifndef TREASURETYPE
#define TREASURETYPE

enum class TreasureType
{
    NormalTreasure,
    SmallHoard,
    MerchantsHoard,
    DragonHoard,
    BarrierSuit
};

#endif
