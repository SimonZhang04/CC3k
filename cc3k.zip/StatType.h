#ifndef STATTYPE
#define STATTYPE

enum class StatType
{
    Attack,
    Defense,
    Health,
    ReceivedDamageMultiplier
};

#endif
